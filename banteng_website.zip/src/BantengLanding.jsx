import React from "react";

const CONTRACT_ADDRESS = "";
const BUY_LINK = `https://pancakeswap.finance/swap?outputCurrency=${CONTRACT_ADDRESS}`;

export default function BantengLanding() {
  return (
    <div className="min-h-screen bg-red-50 text-gray-900 antialiased">
      <header className="bg-red-600 text-white shadow-md">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center font-bold text-lg">🐃</div>
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight">$BANTENG</h1>
              <p className="text-xs opacity-80">From Sawah to the Moon</p>
            </div>
          </div>
          <nav className="flex items-center gap-3">
            <a className="text-sm hover:underline" href="#about">About</a>
            <a className="text-sm hover:underline" href="#tokenomics">Tokenomics</a>
            <a className="text-sm hover:underline" href="#roadmap">Roadmap</a>
            <a className="text-sm hover:underline" href="#community">Community</a>
            <a
              className="ml-3 inline-block bg-yellow-400 text-red-700 font-semibold px-4 py-2 rounded-xl hover:scale-105 transition-transform"
              href={BUY_LINK}
              target="_blank"
              rel="noreferrer"
            >
              Buy $BANTENG
            </a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-extrabold text-red-700">$BANTENG</h2>
            <p className="mt-4 text-lg text-gray-700">Ngamuk pas merah, terbang pas hijau — <strong>the Bullish Spirit of Nusantara.</strong></p>

            <div className="mt-6 flex flex-wrap gap-3">
              <a href={BUY_LINK} target="_blank" rel="noreferrer" className="bg-red-700 text-white font-bold px-5 py-3 rounded-xl shadow-sm hover:opacity-95">Buy $BANTENG</a>
              <a href="#community" className="border border-red-700 text-red-700 px-5 py-3 rounded-xl hover:bg-red-50">Join Community</a>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-3">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500">Total Supply</div>
                <div className="font-bold text-lg">1,000,000,000</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500">Network</div>
                <div className="font-bold text-lg">BSC</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500">Tax</div>
                <div className="font-bold text-lg">0%</div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center">
            <img src="/assets/mascot.png" alt="Si Tanduk - $BANTENG mascot" className="w-full max-w-sm rounded-2xl shadow-2xl" />
          </div>
        </section>

        <section id="about" className="mt-16 bg-white p-8 rounded-2xl shadow-sm">
          <h3 className="text-2xl font-bold text-red-700">About $BANTENG</h3>
          <p className="mt-3 text-gray-700 leading-relaxed">$BANTENG adalah token meme yang mewakili semangat investor Indonesia — pantang menyerah, suka FOMO, dan siap menanduk setiap candle merah 💢.
Token ini bukan cuma soal uang, tapi gaya hidup degen + budaya lokal:
“Dari sawah ke bulan 🌾🚀”</p>

          <ul className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <li className="p-4 border rounded-lg">
              <div className="text-sm text-gray-500">Lore</div>
              <div className="font-semibold">Si Tanduk: banteng legendaris yang menanduk FUD.</div>
            </li>
            <li className="p-4 border rounded-lg">
              <div className="text-sm text-gray-500">Mission</div>
              <div className="font-semibold">Membangun komunitas meme Indonesia yang kocak dan solid.</div>
            </li>
          </ul>
        </section>

        <section id="tokenomics" className="mt-12">
          <h3 className="text-2xl font-bold text-red-700">Tokenomics</h3>
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm">
              <p className="text-gray-700">Total Supply: <strong>1,000,000,000 $BANTENG</strong></p>
              <div className="mt-4">
                <div className="w-full bg-gray-100 rounded-full h-4 overflow-hidden">
                  <div className="h-4 rounded-full bg-red-600" style={{ width: '50%' }} />
                </div>
                <div className="mt-3 text-sm text-gray-600">Community & Airdrop — 50%</div>

                <div className="w-full bg-gray-100 rounded-full h-4 overflow-hidden mt-3">
                  <div className="h-4 rounded-full bg-yellow-400" style={{ width: '30%' }} />
                </div>
                <div className="mt-3 text-sm text-gray-600">Liquidity — 30%</div>

                <div className="w-full bg-gray-100 rounded-full h-4 overflow-hidden mt-3">
                  <div className="h-4 rounded-full bg-green-500" style={{ width: '10%' }} />
                </div>
                <div className="mt-3 text-sm text-gray-600">Team & Marketing — 10%</div>

                <div className="w-full bg-gray-100 rounded-full h-4 overflow-hidden mt-3">
                  <div className="h-4 rounded-full bg-gray-500" style={{ width: '10%' }} />
                </div>
                <div className="mt-3 text-sm text-gray-600">Burn Reserve — 10%</div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm">
              <h4 className="font-semibold">Distribution Notes</h4>
              <ul className="mt-3 list-disc pl-5 text-gray-700">
                <li>Community & Airdrop untuk menumbuhkan viralitas awal.</li>
                <li>Team tokens dikunci selama 6 bulan untuk transparansi.</li>
                <li>Burn events periodik (\"Banteng Ngamuk Day\").</li>
              </ul>

              <div className="mt-6">
                <a href="#" className="inline-block bg-red-600 text-white px-4 py-2 rounded-lg">See Contract</a>
              </div>
            </div>
          </div>
        </section>

        <section id="roadmap" className="mt-12 bg-white p-6 rounded-2xl shadow-sm">
          <h3 className="text-2xl font-bold text-red-700">Roadmap</h3>
          <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border rounded-lg">
              <h4 className="font-bold">Phase 1 — Awakening</h4>
              <ul className="mt-2 list-disc pl-5 text-gray-700">
                <li>Deploy token</li>
                <li>Website & socials live</li>
                <li>Airdrop & meme contest</li>
              </ul>
            </div>
            <div className="p-4 border rounded-lg">
              <h4 className="font-bold">Phase 2 — Community</h4>
              <ul className="mt-2 list-disc pl-5 text-gray-700">
                <li>Burn event</li>
                <li>Sticker pack & NFT</li>
                <li>Collabs with meme projects</li>
              </ul>
            </div>
            <div className="p-4 border rounded-lg">
              <h4 className="font-bold">Phase 3 — Moon</h4>
              <ul className="mt-2 list-disc pl-5 text-gray-700">
                <li>Listing & CMC/CG</li>
                <li>Mini game</li>
                <li>Global meme collabs</li>
              </ul>
            </div>
          </div>
        </section>

        <section id="community" className="mt-12">
          <h3 className="text-2xl font-bold text-red-700">Community</h3>
          <p className="mt-3 text-gray-700">Join the herd! Kita aktif di Telegram & X — banyak kontes, meme war, dan event "Banteng Ngamuk Day".</p>

          <div className="mt-6 flex flex-wrap gap-3">
            <a href="https://t.me/bantengtoken" target="_blank" rel="noreferrer" className="inline-block bg-blue-600 text-white px-5 py-3 rounded-lg">Join Telegram</a>
            <a href="https://x.com/bantengtoken" target="_blank" rel="noreferrer" className="inline-block border border-gray-300 px-5 py-3 rounded-lg">Follow on X</a>
            <a href="#" className="inline-block border border-gray-300 px-5 py-3 rounded-lg">Whitepaper (Coming)</a>
          </div>
        </section>

        <footer className="mt-16 text-center text-sm text-gray-500">
          <div>Not financial advice. This is a meme token for entertainment and community only.</div>
          <div className="mt-2">© {new Date().getFullYear()} $BANTENG — From Sawah to the Moon</div>
        </footer>
      </main>
    </div>
  );
}