import React from 'react'
import { createRoot } from 'react-dom/client'
import BantengLanding from './BantengLanding'
import './index.css'

createRoot(document.getElementById('root')).render(<BantengLanding />)